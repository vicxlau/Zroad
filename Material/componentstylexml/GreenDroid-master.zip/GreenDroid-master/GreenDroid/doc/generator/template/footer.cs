<div id="footer">
    Except as noted, this content is licensed under <a href="http://www.apache.org/licenses/LICENSE-2.0">Apache 2.0</a>.
</div> <!-- end footer -->
