package com.codeundone.andevcon.demo01;

import android.app.Activity;
import android.os.Bundle;

import com.codeundone.andevcon.R;

public class StylesThemesActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.demo_01_styles_themes_view);
	}
}
