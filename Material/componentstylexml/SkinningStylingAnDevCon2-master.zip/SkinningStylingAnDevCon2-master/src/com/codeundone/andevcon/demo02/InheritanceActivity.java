package com.codeundone.andevcon.demo02;

import android.app.Activity;
import android.os.Bundle;

import com.codeundone.andevcon.R;

public class InheritanceActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.demo_02_inheritance_view);
	}
}
