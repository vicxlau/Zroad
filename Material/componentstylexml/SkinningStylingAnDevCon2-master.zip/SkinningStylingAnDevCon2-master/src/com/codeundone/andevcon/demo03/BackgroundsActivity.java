package com.codeundone.andevcon.demo03;

import android.app.Activity;
import android.os.Bundle;

import com.codeundone.andevcon.R;

public class BackgroundsActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.demo_03_backgrounds_view);
	}
}
