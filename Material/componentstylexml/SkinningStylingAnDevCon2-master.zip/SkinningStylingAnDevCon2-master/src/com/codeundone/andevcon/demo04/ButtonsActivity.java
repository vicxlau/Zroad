package com.codeundone.andevcon.demo04;

import android.app.Activity;
import android.os.Bundle;

import com.codeundone.andevcon.R;

public class ButtonsActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.demo_04_buttons_view);
	}
}
