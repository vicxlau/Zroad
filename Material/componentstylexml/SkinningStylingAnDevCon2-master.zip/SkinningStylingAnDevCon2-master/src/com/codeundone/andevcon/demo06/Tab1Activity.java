package com.codeundone.andevcon.demo06;

import android.app.Activity;

public class Tab1Activity extends Activity {

}
