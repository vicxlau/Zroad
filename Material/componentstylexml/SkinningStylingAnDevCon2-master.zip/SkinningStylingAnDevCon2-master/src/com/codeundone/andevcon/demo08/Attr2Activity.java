package com.codeundone.andevcon.demo08;

import android.app.Activity;
import android.os.Bundle;

import com.codeundone.andevcon.R;

public class Attr2Activity extends Activity {
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.demo_08_view);
	}
}
