package com.codeundone.andevcon.demo08;

import android.app.Activity;

public class Draw9PatchActivity extends Activity {

}
