package com.codeundone.andevcon.demo09;

import android.app.Activity;
import android.os.Bundle;

import com.codeundone.andevcon.R;

public class WidgetsActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.demo_09_view);
	}
}
